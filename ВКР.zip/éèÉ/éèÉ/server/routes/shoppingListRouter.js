const Router = require('express')
const router = new Router()
const shoppingController = require('../controllers/shoppingController')
const checkRoleMiddleware = require('../middleware/checkRoleMiddleware')


router.post('/', checkRoleMiddleware(['admin', 'customer']), shoppingController.create)
router.get('/', checkRoleMiddleware(['admin', 'photograph', 'manager']), shoppingController.get)

module.exports = router