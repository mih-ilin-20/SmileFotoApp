const Router = require('express')
const router = new Router()
const incomeController = require('../controllers/incomeController')
const checkRoleMiddleware = require('../middleware/checkRoleMiddleware')

router.post('/', checkRoleMiddleware(['admin']), incomeController.create);
router.get('/', checkRoleMiddleware(['admin', 'photograph', 'manager']), incomeController.get)

module.exports = router