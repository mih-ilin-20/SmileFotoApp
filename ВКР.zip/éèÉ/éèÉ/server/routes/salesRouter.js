const Router = require('express')
const router = new Router()
const saleController = require('../controllers/saleController')
const checkRoleMiddleware = require('../middleware/checkRoleMiddleware')

router.post('/', checkRoleMiddleware(['admin']), saleController.create);
router.get('/', checkRoleMiddleware(['admin', 'photograph', 'manager']), saleController.get)

module.exports = router