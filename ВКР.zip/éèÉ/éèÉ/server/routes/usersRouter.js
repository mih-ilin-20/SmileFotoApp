const Router = require('express')
const router = new Router()
const userController = require('../controllers/userController')
const authMiddleware = require('../middleware/authMiddleware')
const checkRoleMiddleware = require('../middleware/checkRoleMiddleware')

router.post('/registration', userController.registration)
router.post('/login', userController.login)
router.get('/auth', authMiddleware, userController.check)
router.get('/', checkRoleMiddleware(['customer', 'admin', 'photograph', 'manager']), userController.get)
router.get('/employee', checkRoleMiddleware(['manager']), userController.getEmployees)
// router.post('/employee', checkRoleMiddleware(['manager']), userController.getEmployees)

module.exports = router
