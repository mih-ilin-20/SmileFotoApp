const Router = require('express')
const router = new Router()
const inventoryController = require('../controllers/inventoryController')
const checkRoleMiddleware = require('../middleware/checkRoleMiddleware')

router.post('/', checkRoleMiddleware(['admin', 'manager']), inventoryController.create);
router.get('/', checkRoleMiddleware(['admin', 'manager']), inventoryController.get)
router.post('/d', checkRoleMiddleware(['admin', 'manager']), inventoryController.delete)

module.exports = router