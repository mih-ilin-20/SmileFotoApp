const Router = require('express')
const router = new Router()

const usersRouter = require('./usersRouter')
const salesRouter = require('./salesRouter')
const shiftRouter = require('./shiftRouter')
const inventoryRouter = require('./inventoryRouter')
const shoppingListRouter = require('./shoppingListRouter')
const incomeRouter = require('./incomeRouter')

router.use('/user', usersRouter)
router.use('/sales', salesRouter)
router.use('/shift', shiftRouter)
router.use('/inventory', inventoryRouter)
router.use('/shoppingList', shoppingListRouter)
router.use('/income', incomeRouter)

module.exports = router