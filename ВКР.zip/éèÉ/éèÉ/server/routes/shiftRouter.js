const Router = require('express')
const router = new Router()
const shiftController = require('../controllers/shiftController')
const checkRoleMiddleware = require('../middleware/checkRoleMiddleware')

router.post('/', checkRoleMiddleware(['manager']), shiftController.create);
router.get('/', checkRoleMiddleware(['admin', 'photograph', 'manager']),shiftController.get)

module.exports = router