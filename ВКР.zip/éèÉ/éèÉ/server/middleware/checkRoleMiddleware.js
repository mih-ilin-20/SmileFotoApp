const jwt = require('jsonwebtoken')

module.exports = (roles) => {
    return function (req, res, next) {
        if (req.method === "OPTIONS") {
            next()
        }
        try {
            const token = req.headers.authorization.split(' ')[1]

            if (!token) {
                return res.status(403).json('Не авторизован!');
            }
            const decodedToken = jwt.verify(token, process.env.SECRET_KEY)

            if (!roles.includes(decodedToken.role)) {
                return res.status(403).json('Нет доступа!')
            }

            req.user = decodedToken
            next()

        } catch (error) {
            return res.status(403).json('Не авторизован!');
        }
    }
}
