const {DataTypes, TEXT, DATE} = require('sequelize');
const sequelize = require('../db');

// Admin Model
const Users = sequelize.define('users', {
    id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
    full_name: {type: DataTypes.STRING},
    role: {type: DataTypes.STRING, defaultValue: "customer"},
    phone_number: {type: DataTypes.TEXT,  unique: true, allowNull: false},
    email: {type: DataTypes.STRING, unique: true, allowNull: false},
    password: {type: DataTypes.STRING, allowNull: false},
    income_per_month: {type: DataTypes.INTEGER}
});

// Shift Model
const ShiftList = sequelize.define('shift', {
    id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
    shift_date: {type: DATE, allowNull: false},
    photographers: {type: DataTypes.TEXT, allowNull: false},
    administrators: {type: DataTypes.TEXT, allowNull: false}
});

// Inventory Model
const Inventory = sequelize.define('inventory', {
    id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
    name: {type: DataTypes.TEXT, allowNull: false},
    price: {type: DataTypes.INTEGER, allowNull: false},
    quantity_in_stock: {type: DataTypes.INTEGER, allowNull: false},
    description: {type: DataTypes.TEXT, allowNull: true}
});

// Sales Model
const Sales = sequelize.define('sales', {
    id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
    shift_date: {type: DATE, allowNull: false, defaultValue: sequelize.fn('NOW')},
    shopping_id: {type: DataTypes.INTEGER},
    photo_quantity: {type: DataTypes.INTEGER},
    sale_amount: {type: DataTypes.INTEGER, allowNull: false},
    photographer_name: {type: DataTypes.TEXT, allowNull: false},
    user_id: {type: DataTypes.INTEGER, allowNull: false},
    description: {type: DataTypes.TEXT, allowNull: true}
});

// ShoppingList Model
const ShoppingList = sequelize.define('shopping_list', {
    id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
    group: {type: DataTypes.INTEGER, allowNull: false},
    item_id: {type: DataTypes.INTEGER, allowNull: false},
    item_quantity: {type: DataTypes.INTEGER, allowNull: false}
});

// IncomeEmployee Model
const IncomeEmployee = sequelize.define('income', {
    id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
    shift_date: {type: TEXT, allowNull: false, unique: true},
    day_of_week: {type: DataTypes.TEXT, allowNull: false},
    revenue: {type: DataTypes.INTEGER, allowNull: false},
    percentage: {type: DataTypes.INTEGER, allowNull: false},
    name: {type: DataTypes.TEXT, allowNull: false},
    income: {type: DataTypes.INTEGER, allowNull: false},
});

const Income_Users = sequelize.define('income_users',
    {
        id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true}
    })

const Users_Shift = sequelize.define('users_shift',
    {
        id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true}
    })

// Define relationships
ShiftList.hasMany(IncomeEmployee);
IncomeEmployee.belongsTo(ShiftList);

ShiftList.hasMany(Sales);
Sales.belongsTo(ShiftList);

Users.hasMany(Sales);
Sales.belongsTo(Users);

Users.belongsToMany(ShiftList, {through: Users_Shift});
ShiftList.belongsToMany(Users, {through: Users_Shift});

Users.belongsToMany(IncomeEmployee, {through: Income_Users});
IncomeEmployee.belongsToMany(Users, {through: Income_Users});

ShoppingList.hasMany(Sales);
Sales.belongsTo(ShoppingList);

Inventory.hasMany(ShoppingList, {as: 'shop_l'});
ShoppingList.belongsTo(Inventory);

module.exports = {
    Users,
    ShiftList,
    Inventory,
    Sales,
    ShoppingList,
    IncomeEmployee
};
