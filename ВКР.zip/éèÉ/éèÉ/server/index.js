require('dotenv').config();

const { Sequelize } = require('sequelize');

module.exports = new Sequelize(
    process.env.DB_NAME,
    process.env.DB_USER,
    process.env.DB_PASSWORD,
    {
        dialect: 'postgres',
        host: process.env.DB_HOST,
        port: process.env.DB_PORT
    }
);

const express = require('express')
const sequelize = require('./db')
const cors = require('cors')
const router = require('./routes/index')
const PORT = process.env.PORT || 5000
const app = express()
const cron = require('node-cron');
const {Users} = require("./models/models");
const apiError = require('./middleware/errorHandlingMiddleware')

app.use(cors())
app.use(express.json())
app.use('/', router)

app.use(apiError)

const start = async () => {
    try {
        await sequelize.authenticate()
        await sequelize.sync()
        app.listen(PORT, () => console.log(`Server start on port ${PORT}`))
    } catch (e) {
        console.log(e)
    }
}

cron.schedule('0 0 1 * *', async () => {
    try {
        const users = await Users.findAll();

        for (const user of users) {
            user.income = 0;
            await user.save();
        }
    } catch (error) {
        console.log(error.status + error.message);
    }
});

start();