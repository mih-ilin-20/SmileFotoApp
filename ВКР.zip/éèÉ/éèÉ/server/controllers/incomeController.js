const apiError = require('../error/ApiError')
const {IncomeEmployee, Users} = require('../models/models')
const jwt = require('jsonwebtoken');
const moment = require("moment/moment");
const sequelize = require("../db");
const cron = require('node-cron')
const {Op} = require("sequelize");

class IncomeController {
    async create(req, res, next) {
        try {
            const {name, income} = req.body
            const token = req.headers.authorization.split(' ')[1]

            if (!token) {
                return next(apiError.forbidden('Не авторизован!'));
            }

            if (!name || !income) {
                return next(apiError.badRequest('Все поля должны быть заполнены обязательно!'));
            }

            const decodedToken = jwt.verify(token, process.env.SECRET_KEY)
            let u_role;

            if (decodedToken.role === 'admin')
                u_role = 'admin'
            else if (decodedToken.role === 'photograph')
                u_role = 'photograph'

            let day_of_week = moment().format('dddd');
            day_of_week = day_of_week.charAt(0).toUpperCase() + day_of_week.slice(1);
            let revenue, percentage;

            if (u_role === 'admin') {
                if (day_of_week === 'Понедельник')
                    revenue = 2000
                else revenue = 1400
                percentage = 2
            }

            if (u_role === 'photograph') {
                revenue = 0
                percentage = 30
            }

            const user = await Users.findByPk(decodedToken.id)
            const incoming = await IncomeEmployee.create({
                shift_date: sequelize.fn('NOW'),
                day_of_week: day_of_week,
                revenue,
                percentage,
                name,
                income
            });

            user.income += income * percentage / 100 + revenue;
            await user.save();

            return res.json(incoming);
        } catch (error) {
            return next(apiError.internal(error.message));
        }
    }

    async get(req, res, next) {
        try {
            let {limit, page} = await req.query
            page = page || 1
            limit = limit || 20
            let offset = page * limit - limit

            let items = await IncomeEmployee.findAll()
            if (!items || items.length === 0) {
                return next(apiError.badRequest('Нет данных!'));
            }
            items = await IncomeEmployee.findAndCountAll({
                limit,
                offset,
                order: [['id', 'ASC']]
            })

            return res.json(items);
        } catch (error) {
            return next(apiError.internal(error.message));
        }
    }
}

module.exports = new IncomeController()