const apiError = require('../error/ApiError')
const {Sales, ShoppingList, Inventory} = require('../models/models')
const sequelize = require('../db');
const moment = require('moment');
const localeData = require('moment/locale/ru');


moment.updateLocale('ru', localeData);

class SaleController {
    async create(req, res, next) {
        try {
            const {shopping_id, photo_quantity, photographer_name, user_id, description} = req.body;
            let photo_amount = 0;
            let sale_amount = 0;

            if (!photographer_name || !user_id)
                return next(apiError.badRequest('Все поля, кроме описания, должны быть заполнены обязательно!'));

            if (!photo_quantity && !shopping_id)
                return next(apiError.badRequest('Значения количества фото ' +
                    'и проданного инвентаря не могут быть пустыми одновременно!'))

            if (photo_quantity) {
                if (photo_quantity < 1) {
                    return next(apiError.badRequest('Введите количество больше 1!'));
                } else if (photo_quantity > 1 && photo_quantity < 5) {
                    photo_amount = photo_quantity * 350
                } else if (photo_quantity > 4 && photo_quantity < 8) {
                    photo_amount = photo_quantity * 250
                } else if (photo_quantity > 7) {
                    photo_amount = photo_quantity * 200
                }
            }

            if (shopping_id) {
                const shoppingListItems = await ShoppingList.findAll({
                    where: {
                        group: shopping_id
                    }
                });

                if (!shoppingListItems) {
                    return next(apiError.badRequest('Нет продаж из инвентаря!'));
                }

                for (const item of shoppingListItems) {
                    const inventoryPrice = await Inventory.findByPk(item.item_id)

                    if (!inventoryPrice) {
                        return next(apiError.badRequest('Нет элементов в инвентаре!'));
                    }

                    const price = inventoryPrice.price;
                    sale_amount += price * item.item_quantity;
                }
            }

            const shop_amount = sale_amount + photo_amount;
            const sale = await Sales.create({
                shift_date: sequelize.fn('NOW'),
                shopping_id: shopping_id,
                photo_quantity: photo_quantity,
                sale_amount: shop_amount,
                photographer_name: photographer_name,
                user_id: user_id,
                description
            });

            res.json(sale)
        } catch (error) {
            return next(apiError.internal(error.message));
        }
    }

    async get(req, res, next) {
        try {
            let {limit, page} = await req.query
            page = page || 1
            limit = limit || 20
            let offset = page * limit - limit

            let items = await Sales.findAll({order: [['id', 'ASC']]})
            if (!items || items.length === 0) {
                return next(apiError.badRequest('Нет данных!'));
            }
            items = await Sales.findAndCountAll({limit, offset})

            return res.json(items);
        } catch (error) {
            return next(apiError.internal(error.message));
        }
    }
}

module.exports = new SaleController()