const apiError = require('../error/ApiError')
const {ShoppingList, Inventory} = require('../models/models')

class ShoppingController {
    async create(req, res, next) {
        try {
            let {s_list_info} = req.body
            if (!s_list_info)
                return next(apiError.badRequest('Введите значение!'));

            // Получаем последнее значение group из базы данных
            const lastGroup = await ShoppingList.max('group')
            const temp = lastGroup ? lastGroup + 1 : 1

            const createdItems = []

            for (const i of s_list_info) {
                const t = await Inventory.findByPk(i.item_id)

                if (t && t.quantity_in_stock >= i.item_quantity) {
                    const item = await ShoppingList.create({
                        group: temp,
                        item_id: i.item_id,
                        item_quantity: i.item_quantity
                    })

                    // Обновляем количество товара на складе
                    t.quantity_in_stock -= i.item_quantity
                    await t.save()

                    createdItems.push(item)

                } else return next(apiError.badRequest('Превышено допустимое количество!'))
            }

            res.json({item: createdItems})
        } catch (error) {
            return next(apiError.internal(error.message));
        }
    }


    async get(req, res, next) {
        try {
            const list = await ShoppingList.findAll({order: [['id', 'ASC']]})

            if (!list || list.length === 0) {
                return next(apiError.badRequest('Нет данных!'));
            }

            return res.json(list);
        } catch
            (error) {
            return next(apiError.internal(error.message));
        }
    }
}

module.exports = new ShoppingController()