const apiError = require('../error/ApiError')
const {Inventory} = require('../models/models')

class InventoryController {
    async create(req, res, next) {
        try {
            const {name, price, quantity_in_stock, description} = req.body;

            if (!name || !price || !quantity_in_stock)
                return next(apiError.badRequest('Все поля, кроме описания, должны быть заполнены обязательно!'));

            const inventoryItem = await Inventory.create({
                name,
                price,
                quantity_in_stock,
                description
            });

            return res.json(inventoryItem);
        } catch (error) {
            return next(apiError.internal(error.message));
        }
    }

    async get(req, res, next) {
        try {
            let {limit, page} = await req.query
            page = page || 1
            limit = limit || 20
            let offset = page * limit - limit

            let items = await Inventory.findAll()
            if (!items || items.length === 0) {
                return next(apiError.badRequest('Нет данных!'));
            }
            items = await Inventory.findAndCountAll({
                limit,
                offset,
                order: [['id', 'ASC']] // сортировка по id в порядке возрастания
            })

            return res.json(items);
        } catch (error) {
            return next(apiError.internal(error.message));
        }
    }

    async delete(req, res, next) {
        try {
            const {id} = req.body;
            const item = await Inventory.findByPk(id);
            if (!item) {
                return next(apiError.badRequest('Укажите верный ID!'))
            }
            await item.destroy();
            return res.json('Успешно удалено!')
        } catch (error) {
            return next(apiError.internal(error.message));
        }
    }
}

module.exports = new InventoryController()