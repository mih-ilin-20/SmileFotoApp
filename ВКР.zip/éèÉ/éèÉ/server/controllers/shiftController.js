const apiError = require('../error/ApiError')
const {ShiftList} = require('../models/models')

class ShiftController {
    async create(req, res, next) {
        const {shift_date, photographers, administrators} = req.body;

        try {
            const newShift = await ShiftList.create({
                shift_date,
                photographers: JSON.stringify(photographers),
                administrators: JSON.stringify(administrators)
            });

            return res.json(newShift);
        } catch (error) {
            return next(apiError.internal(error.message));
        }
    }


    async get(req, res, next) {
        try {
            const shift = await ShiftList.findAll({order: [['id', 'ASC']]})
            if (!shift || shift.length === 0) {
                return next(apiError.badRequest('Нет данных!'));
            }

            return res.json(shift)
        } catch (error) {
            return next(apiError.internal(error.message));
        }
    }
}

module.exports = new ShiftController()