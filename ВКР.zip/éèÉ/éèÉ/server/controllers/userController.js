const apiError = require('../error/ApiError')
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
const {Users} = require('../models/models')
const {Op} = require("sequelize");

const generateJwt = (id, phone_number, email, role) => {
    return jwt.sign(
        {id, phone_number, email, role},
        process.env.SECRET_KEY,
        {expiresIn: '12h'})
}

class UserController {
    async registration(req, res, next) {
        try {
            const {phone_number, email, password, role} = req.body

            if (!phone_number || !email || !password)
                return next(apiError.badRequest('Заполните все поля'));

            const candidate = await Users.findOne({where: {email}})
            if (candidate) {
                return next(apiError.badRequest('Данный пользователь уже существует!'));
            }

            const hashPassword = await bcrypt.hash(password, 4)
            const user = await Users.create({
                phone_number: phone_number,
                role: role,
                email: email,
                password: hashPassword,
            })
            const token = generateJwt(
                user.id,
                user.phone_number,
                user.email,
                user.role)

            return res.json({token})
        } catch (error) {
            return next(apiError.internal(error.message));
        }
    }

    async login(req, res, next) {
        try {
            const {email, password} = req.body
            const user = await Users.findOne({where: {email}})

            if (!user) {
                return next(apiError.badRequest('Пользователь не существует!'));
            }

            let comparePasswords = bcrypt.compareSync(password, user.password)

            if (!comparePasswords) {
                return next(apiError.badRequest('Неверный пароль!'));
            }

            const token = generateJwt(
                user.id,
                user.phone_number,
                user.email,
                user.role)

            return res.json(token);
        } catch (error) {
            return next(apiError.internal(error.message));
        }
    }

    async check(req, res, next) {
        try {
            const token = generateJwt(
                req.user.id,
                req.user.phone_number,
                req.user.email,
                req.user.role)

            return res.json({token});
        } catch (error) {
            return next(apiError.internal(error.message));
        }
    }

    async get(req, res, next) {
        try {
            let item;
            const checking_role = await Users.findByPk(req.user.id, {attributes: ['role']})

            if (checking_role.role === 'customer') {
                item = await Users.findByPk(
                    req.user.id,
                    {attributes: ['full_name', 'phone_number', 'email']});
            }
            if (checking_role.role === 'admin' ||
                checking_role.role === 'photograph') {
                item = await Users.findOne({
                    where: {
                        id: req.user.id,
                        role: {
                            [Op.or]: ['admin', 'photograph']
                        }
                    },
                    attributes: ['full_name', 'phone_number', 'email', 'income_per_month']
                });
            }

            return res.json(item);

        } catch (error) {
            return next(apiError.internal(error.message));
        }
    }

    async getEmployees(req, res, next) {
        try {
            let items = await Users.findAll({
                where: {
                    role: {
                        [Op.or]: ['admin', 'photograph']
                    }
                },
                order: [['id', 'ASC']],
                attributes: ['id', 'full_name', 'phone_number', 'email', 'income_per_month']


            })
            if (!items || items.length === 0) {
                return next(apiError.badRequest('Нет данных!'));
            }

            return res.json(items);
        } catch (error) {
            return next(apiError.internal(error.message));
        }
    }
}

module.exports = new UserController()