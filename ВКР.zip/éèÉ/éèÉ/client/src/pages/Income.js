import React from 'react';

const Income = () => {
    return (
        <div>
            Income
        </div>
    );
};

export default Income;