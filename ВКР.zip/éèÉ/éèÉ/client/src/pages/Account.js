import React, {useContext} from 'react';
import {Col, Container} from "react-bootstrap";
import {observer} from "mobx-react-lite";
import {Context} from "../index";

const Account = observer(() => {
    const {user} = useContext(Context);

    return (
        <div>
            {user._isAuth ? (
                    <Container>
                        <Col md={4}>fdsfdsfdsfds</Col>
                        <Col md={10}>[f[ff[</Col>
                    </Container>
                )
                :
                <div>

                </div>
            }
        </div>
    );
});

export default Account;