import React from 'react';

const Shift = () => {
    return (
        <div>
            Shift
        </div>
    );
};

export default Shift;