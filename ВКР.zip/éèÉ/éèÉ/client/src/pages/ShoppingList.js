import React from 'react';

const ShoppingList = () => {
    return (
        <div>
            ShoppingList
        </div>
    );
};

export default ShoppingList;