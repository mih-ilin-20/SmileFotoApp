import React, {useContext, useState} from 'react';
import {Button, Card, Container, Form, Row, Col, FormGroup} from "react-bootstrap";
import {NavLink, useLocation, useNavigate} from "react-router-dom";
import {ACCOUNT_ROUTE, LOGIN_ROUTE, REGISTRATION_ROUTE} from "../utils/consts";
import {login, registration} from "../http/userAPI";
// import {jwtDecode} from "jwt-decode";
import {observer} from "mobx-react-lite";
import {Context} from "../index";

const Auth = observer(() => {
    const {user} = useContext(Context)
    const isReg = useLocation().pathname === REGISTRATION_ROUTE;
    const navigate = useNavigate();
    const [phone_number, setPhoneNumber] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const click = async () => {
        try {
            let data;
            if (isReg) {
                data = await registration(phone_number, email, password);
            } else {
                data = await login(email, password);
            }
            user.setUser(user)
            user.setIsAuth(true)
            navigate(ACCOUNT_ROUTE);
        } catch (e) {
            alert(e.response.data.message)
        }
    };

    return (
        <Container
            className='d-flex justify-content-center align-items-center'
            style={{height: window.innerHeight - 92}}
        >
            <Card style={{width: window.innerWidth * 0.35}} className='p-4'>
                <h2 className='m-auto'>{isReg ? 'Регистрация' : 'Авторизация'}</h2>
                <Form className='d-flex flex-column'>
                    {isReg && (
                        <FormGroup className='mt-3' as={Row}>
                            <Form.Label column sm="4">Номер телефона</Form.Label>
                            <Col sm={8}>
                                <Form.Control
                                    sm="2"
                                    type='tel'
                                    placeholder='+7 (999) 999-99-99'
                                    value={phone_number}
                                    onChange={e => setPhoneNumber(e.target.value)}
                                />
                            </Col>
                        </FormGroup>
                    )}
                    <FormGroup className='mt-3' as={Row}>
                        <Form.Label column sm="4">Email</Form.Label>
                        <Col sm={8}>
                            <Form.Control
                                sm='2'
                                value={email}
                                placeholder='name@example.com'
                                onChange={e => setEmail(e.target.value)}
                            />
                        </Col>
                    </FormGroup>
                    <FormGroup className='mt-3' as={Row}>
                        <Form.Label column sm="4">Пароль</Form.Label>
                        <Col sm={8}>
                            <Form.Control
                                sm='2'
                                placeholder='••••••••'
                                value={password}
                                onChange={e => setPassword(e.target.value)}
                                type='password'
                            />
                        </Col>
                    </FormGroup>
                    <Row className='d-flex justify-content-between align-items-center mt-3 pe-3'>
                        <Col>
                            <div style={{width: 'auto'}}>
                                {isReg ? 'Уже есть аккаунт?' : 'Нет аккаунта?'}
                            </div>
                            <NavLink
                                to={isReg ? LOGIN_ROUTE : REGISTRATION_ROUTE}
                                style={{
                                    borderBottom: '2px solid black',
                                    color: 'darkgreen',
                                    textDecoration: 'none',
                                }}
                            >
                                {isReg ? 'Авторизоваться' : 'Зарегистрироваться'}
                            </NavLink>
                        </Col>
                        <Button
                            style={{
                                width: 'auto',
                                height: '3em',
                            }}
                            variant={'outline-success'}
                            onClick={click}
                        >
                            {isReg ? 'Зарегистрироваться' : 'Войти'}
                        </Button>
                    </Row>
                </Form>
            </Card>
        </Container>
    );
});

export default Auth;
