import React from 'react';
import {observer} from "mobx-react-lite";

const Admin = observer(() => {
    return (
        <div>
            Admin
        </div>
    );
});

export default Admin;