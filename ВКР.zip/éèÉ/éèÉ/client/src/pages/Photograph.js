import React from 'react';

const Photograph = () => {
    return (
        <div>
            Photograph
        </div>
    );
};

export default Photograph;