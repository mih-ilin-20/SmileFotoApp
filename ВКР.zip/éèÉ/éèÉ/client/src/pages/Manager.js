import React from 'react';

const Manager = () => {
    return (
        <div>
            Manager
        </div>
    );
};

export default Manager;