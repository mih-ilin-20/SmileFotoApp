import React, {useContext} from 'react';
import {observer} from "mobx-react-lite";
import {Context} from "../index";
import {Nav, Navbar, Button} from "react-bootstrap";
import '../styles/NavBar.css';
import {useNavigate} from "react-router-dom";
import {ACCOUNT_ROUTE, INCOME_ROUTE, INVENTORY_ROUTE, SALES_ROUTE} from "../utils/consts";

const NavBar = observer(() => {
    const {user} = useContext(Context);
    const navigate = useNavigate();

    console.log(user)
    return (
        <Navbar className="header">
            <Navbar.Brand>
                <img
                    src="https://smilefoto.me/assets/32831d4f/images/logo.jpg"
                    alt="Logo"
                />
            </Navbar.Brand>
            <Navbar.Toggle aria-controls="basic-navbar-nav"/>
            <Nav className="nav-buttons">
                {user.isAuth ? (
                        <>
                            <Button className="nav-button"
                                    variant="outline-dark"
                                    onClick={navigate(ACCOUNT_ROUTE)}
                            >
                                Профиль
                            </Button>
                            <Button className="nav-button"
                                    variant="outline-dark"
                                    onClick={navigate(INVENTORY_ROUTE)}
                            >
                                Инвентарь
                            </Button>
                            <Button className="nav-button"
                                    variant="outline-dark"
                                    onClick={navigate(SALES_ROUTE)}
                            >
                                Создать продажу
                            </Button>
                            <Button className="nav-button"
                                    variant="outline-dark"
                                    onClick={navigate(INCOME_ROUTE)}
                            >
                                Создать отчет смены
                            </Button>
                            <Button
                                className="nav-button"
                                variant="outline-dark"
                                onClick={() => user.setIsAuth(false)}
                            >
                                Выйти
                            </Button>
                        </>
                    ) :
                    <div>
                    </div>}
            </Nav>
        </Navbar>
    );
});

export default NavBar;

