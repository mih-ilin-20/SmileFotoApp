import React from 'react';
import {observer} from "mobx-react-lite";


const ShiftList = observer(() => {
    return (
        <div>

        </div>
    );
});

export default ShiftList;