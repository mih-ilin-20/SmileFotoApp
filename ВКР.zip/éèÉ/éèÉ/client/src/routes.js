import {
    ACCOUNT_ROUTE,
    INCOME_ROUTE,
    INVENTORY_ROUTE,
    LOGIN_ROUTE,
    REGISTRATION_ROUTE,
    SHIFT_ROUTE,
    SHOPPINGLIST_ROUTE,
    SALES_ROUTE
} from "./utils/consts";
import Auth from "./pages/Auth";
import Income from "./pages/Income";
import Account from "./pages/Account";
import Inventory from "./pages/Inventory";
import ShoppingList from "./pages/ShoppingList";
import Shift from "./pages/Shift";
import Sales from "./pages/Sales";

export const authRoutes = [
    {
        path: ACCOUNT_ROUTE + '/admin',
        Component: Account
    },
    {
        path: ACCOUNT_ROUTE + '/photograph',
        Component: Account
    },
    {
        path: ACCOUNT_ROUTE + '/manager',
        Component: Account
    },
    {
        path: ACCOUNT_ROUTE,
        Component: Account
    },
    {
        path: INVENTORY_ROUTE,
        Component: Inventory
    },
    {
        path: INCOME_ROUTE,
        Component: Income
    },
    {
        path: SHIFT_ROUTE,
        Component: Shift
    },
    {
        path: SALES_ROUTE,
        Component: Sales
    }
]

export const publicRoutes = [
    {
        path: LOGIN_ROUTE,
        Component: Auth
    },
    {
        path: REGISTRATION_ROUTE,
        Component: Auth
    },
    {
        path: SHOPPINGLIST_ROUTE,
        Component: ShoppingList
    },
    {
        path: ACCOUNT_ROUTE,
        Component: Account
    },
]