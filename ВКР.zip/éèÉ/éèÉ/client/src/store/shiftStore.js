import {makeAutoObservable} from "mobx";

export default class ShiftStore {
    constructor() {
        this._shifts = [
            {
                id: 1,
                shift_date: "2023-03-12",
                photographers: "John Doe, Jane Doe",
                administrators: "Bob Smith, Alice Johnson",
            },
            {
                id: 2,
                shift_date: "2023-03-13",
                photographers: "John Doe, Jane Doe",
                administrators: "Bob Smith, Alice Johnson",
            },
        ];
        makeAutoObservable(this);
    }

    get shifts() {
        return this._shifts;
    }

    set shifts(value) {
        this._shifts = value;
    }

    addShift(shift) {
        this._shifts.push(shift);
    }

    removeShift(id) {
        this._shifts = this._shifts.filter((item) => item.id !== id);
    }
}