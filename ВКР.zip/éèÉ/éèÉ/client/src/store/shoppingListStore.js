import {makeAutoObservable} from "mobx";

export default class ShoppingListStore {
    constructor() {
        this._shoppingList = [
            {
                id: 1,
                group: 1,
                item_id: 1,
                item_quantity: 10,
            },
            {
                id: 2,
                group: 1,
                item_id: 2,
                item_quantity: 20,
            },
        ];
        makeAutoObservable(this);
    }

    get shoppingList() {
        return this._shoppingList;
    }

    set shoppingList(value) {
        this._shoppingList = value;
    }

    addShoppingListItem(item) {
        this._shoppingList.push(item);
    }

    removeShoppingListItem(id) {
        this._shoppingList = this._shoppingList.filter((item) => item.id !== id);
    }
}
