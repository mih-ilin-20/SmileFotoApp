import {makeAutoObservable} from "mobx";

export default class SalesStore {
    constructor() {
        this._sales = [
            {
                id: 1,
                shift_date: "2023-03-12",
                shopping_id: 1,
                photo_quantity: 10,
                sale_amount: 1000,
                photographer_name: "John Doe",
                user_id: 1,
                description: "Lorem ipsum dolor sit amet",
            },
            {
                id: 2,
                shift_date: "2023-03-13",
                shopping_id: 2,
                photo_quantity: 20,
                sale_amount: 2000,
                photographer_name: "Jane Doe",
                user_id: 2,
                description: "Lorem ipsum dolor sit amet",
            },
        ];
        makeAutoObservable(this);
    }

    get sales() {
        return this._sales;
    }

    set sales(value) {
        this._sales = value;
    }

    addSale(sale) {
        this._sales.push(sale);
    }

    removeSale(id) {
        this._sales = this._sales.filter((item) => item.id !== id);
    }
}
