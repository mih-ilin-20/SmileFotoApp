import {makeAutoObservable} from "mobx";

export default class UserStore {
    constructor() {
        this._isAuth = false
        this._user = [
            {
                id: 1,
                role: "customer",
                phone_number: "+79991112233",
                email: "john@example.com",
                password: "password123"
            },
            {
                id: 2,
                role: "photographer",
                phone_number: "+79993334455",
                email: "jane@example.com",
                password: "qwerty456"
            },
            {
                id: 3,
                role: "administrator",
                phone_number: "+79995556677",
                email: "bob@example.com",
                password: "password789"
            },
            {
                id: 4,
                role: "admin",
                phone_number: "+79997778899",
                email: "alice@example.com",
                password: "qwerty000"
            }
        ];
        makeAutoObservable(this)
    }

    setIsAuth(bool) {
        this._isAuth = bool
    }

    setUser(user) {
        this._user = user
    }

    get isAuth() {
        return this._isAuth
    }

    get user() {
        return this._user
    }
}