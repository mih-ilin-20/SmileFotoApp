import {makeAutoObservable} from "mobx";

export default class InventoryStore {
    constructor() {
        this._inventory = [
            {
                id: 1,
                name: "Product 1",
                price: 100,
                quantity_in_stock: 10,
                description: "Lorem ipsum dolor sit amet",
            },
            {
                id: 2,
                name: "Product 2",
                price: 200,
                quantity_in_stock: 20,
                description: "Lorem ipsum dolor sit amet",
            },
        ];
        makeAutoObservable(this);
    }

    get inventory() {
        return this._inventory;
    }

    set inventory(value) {
        this._inventory = value;
    }

    addInventory(inventory) {
        this._inventory.push(inventory);
    }

    removeInventory(id) {
        this._inventory = this._inventory.filter((item) => item.id !== id);
    }
}
