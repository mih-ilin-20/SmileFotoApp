import {makeAutoObservable} from "mobx";

export default class IncomeStore {
    constructor() {
        this._income = [
            {
                id: 1,
                shift_date: "2023-03-12",
                day_of_week: "Sunday",
                revenue: 5000,
                percentage: 10,
                name: "John Doe",
                income: 500,
            },
            {
                id: 2,
                shift_date: "2023-03-13",
                day_of_week: "Monday",
                revenue: 6000,
                percentage: 10,
                name: "Jane Doe",
                income: 600,
            },
        ];
        makeAutoObservable(this);
    }

    get income() {
        return this._income;
    }

    set income(value) {
        this._income = value;
    }

    addIncome(income) {
        this._income.push(income);
    }

    removeIncome(id) {
        this._income = this._income.filter((income) => income.id !== id);
    }
}
