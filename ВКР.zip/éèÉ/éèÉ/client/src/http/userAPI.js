import {$authHost, $host} from "./index";
import {jwtDecode} from "jwt-decode";

export const registration = async (phone_number, email, password) => {
    const {data} = await $host.post('user/registration', {phone_number, email, password, role: 'admin'});
    localStorage.setItem('token', data.token)
    return jwtDecode(data.token)
}

export const login = async (email, password) => {
    const {data} = await $host.post('user/login', {email, password});
    localStorage.setItem('token', data.token)
    return jwtDecode(data.token)
}

export const check = async () => {
    return await $authHost.post('user/auth')
}